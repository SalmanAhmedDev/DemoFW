//
//  privateFile.h
//  DemoFW
//
//  Created by Salman  Ahmed on 16/04/2018.
//  Copyright © 2018 test. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface privateFile : NSObject

@end
